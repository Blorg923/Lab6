class InvalidCharacterException
   extends ScannerException
{
}

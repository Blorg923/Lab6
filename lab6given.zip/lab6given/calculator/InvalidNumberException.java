class InvalidNumberException
   extends ScannerException
{
}

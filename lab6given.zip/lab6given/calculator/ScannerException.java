class ScannerException
   extends Exception
{
}

